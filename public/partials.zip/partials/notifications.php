<?php
// Helper function to get user profile picture from Supabase
function getUserProfilePicture($email) {
    if (empty($email)) {
        return '';
    }
    
    // Check session first
    if (isset($_SESSION['user_profile_picture']) && !empty($_SESSION['user_profile_picture'])) {
        $profilePic = $_SESSION['user_profile_picture'];
        // Extract filename from path
        $filename = basename($profilePic);
        $picturePath = __DIR__ . '/../uploads/profile/' . $filename;
        if (file_exists($picturePath)) {
            return $profilePic;
        } else {
            // Clear invalid session value
            unset($_SESSION['user_profile_picture']);
        }
    }
    
    // Fetch from Supabase if not in session
    if (defined('SUPABASE_URL') && defined('SUPABASE_ANON_KEY') && SUPABASE_URL !== '' && SUPABASE_ANON_KEY !== '') {
        $supabaseUrl = rtrim(SUPABASE_URL, '/');
        $supabaseKey = SUPABASE_ANON_KEY;
        
        $query = http_build_query([
            'select' => 'profile_picture',
            'email' => 'eq.' . urlencode($email),
            'limit' => 1,
        ]);
        
        $ch = curl_init();
        curl_setopt_array($ch, [
            CURLOPT_URL => $supabaseUrl . '/rest/v1/users?' . $query,
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_HTTPHEADER => [
                'apikey: ' . $supabaseKey,
                'Authorization: Bearer ' . $supabaseKey,
                'Accept: application/json',
            ],
        ]);
        
        $response = curl_exec($ch);
        $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        curl_close($ch);
        
        if ($httpCode === 200 && $response) {
            $rows = json_decode($response, true);
            if (is_array($rows) && count($rows) > 0 && !empty($rows[0]['profile_picture'])) {
                $profilePicture = $rows[0]['profile_picture'];
                // Verify file exists
                $filename = basename($profilePicture);
                $picturePath = __DIR__ . '/../uploads/profile/' . $filename;
                if (file_exists($picturePath)) {
                    $_SESSION['user_profile_picture'] = $profilePicture;
                    return $profilePicture;
                }
            }
        }
    }
    
    return '';
}

// Get user info for notifications
$displayName = $_SESSION['user_name'] ?? ($_SESSION['user_email'] ?? 'User');
$email = $_SESSION['user_email'] ?? '';
$profilePicture = getUserProfilePicture($email);
$userRole = $_SESSION['user_role'] ?? '';
$isAdmin = (strtolower($userRole) === 'admin');

// Fetch recent tickets for notifications
$recentTickets = [];
if (defined('SUPABASE_URL') && defined('SUPABASE_ANON_KEY') && SUPABASE_URL !== '' && SUPABASE_ANON_KEY !== '' && !empty($email)) {
    $supabaseUrl = rtrim(SUPABASE_URL, '/');
    $supabaseKey = SUPABASE_ANON_KEY;
    
    error_log("Notifications debug: User email = " . $email);
    error_log("Notifications debug: User role = " . $userRole);
    error_log("Notifications debug: Is admin = " . ($isAdmin ? 'true' : 'false'));
    error_log("Notifications debug: Supabase URL = " . $supabaseUrl);
    
    if ($isAdmin) {
        // Admins see all open tickets
        $query = http_build_query([
            'select' => 'id,title,status,priority,created_at,requested_by',
            'status' => 'eq.Open',
            'order' => 'created_at.desc',
            'limit' => 5
        ]);
        
        error_log("Notifications debug: Admin query = " . $query);
        
        $allTickets = [];
        
        // Single query for all open tickets
        $ch = curl_init();
        curl_setopt_array($ch, [
            CURLOPT_URL => $supabaseUrl . '/rest/v1/tickets?' . $query,
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_HTTPHEADER => [
                'apikey: ' . $supabaseKey,
                'Authorization: Bearer ' . $supabaseKey,
                'Accept: application/json',
            ],
        ]);
        
        $response = curl_exec($ch);
        $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        curl_close($ch);
        
        error_log("Notifications debug: Admin query HTTP code = " . $httpCode);
        error_log("Notifications debug: Admin query response = " . $response);
        
        if ($httpCode === 200 && $response) {
            $tickets = json_decode($response, true) ?: [];
            error_log("Notifications debug: Admin query decoded tickets = " . print_r($tickets, true));
            $allTickets = array_merge($allTickets, $tickets);
        } else {
            error_log("Notifications debug: Admin query failed");
        }
        
        $recentTickets = array_slice($allTickets, 0, 5);
        
    } else {
        // Regular users only see their own tickets (created by or assigned to)
        // Fetch open tickets created by current user
        $query1 = http_build_query([
            'select' => 'id,title,status,priority,created_at,requested_by',
            'requested_by' => 'eq.' . urlencode($email),
            'status' => 'eq.Open',
            'order' => 'created_at.desc',
            'limit' => 5
        ]);
        
        error_log("Notifications debug: Query1 = " . $query1);
        
        // Fetch open tickets assigned to current user
        $query2 = http_build_query([
            'select' => 'id,title,status,priority,created_at,requested_by,ticket_assignees(technician_email)',
            'ticket_assignees.technician_email' => 'eq.' . urlencode($email),
            'status' => 'eq.Open',
            'order' => 'created_at.desc',
            'limit' => 5
        ]);
        
        error_log("Notifications debug: Query2 = " . $query2);
        
        $allTickets = [];
        
        // First query: tickets created by user
        $ch = curl_init();
        curl_setopt_array($ch, [
            CURLOPT_URL => $supabaseUrl . '/rest/v1/tickets?' . $query1,
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_HTTPHEADER => [
                'apikey: ' . $supabaseKey,
                'Authorization: Bearer ' . $supabaseKey,
                'Accept: application/json',
            ],
        ]);
        
        $response = curl_exec($ch);
        $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        curl_close($ch);
        
        error_log("Notifications debug: Query1 HTTP code = " . $httpCode);
        error_log("Notifications debug: Query1 response = " . $response);
        
        if ($httpCode === 200 && $response) {
            $tickets1 = json_decode($response, true) ?: [];
            error_log("Notifications debug: Query1 decoded tickets = " . print_r($tickets1, true));
            $allTickets = array_merge($allTickets, $tickets1);
        } else {
            error_log("Notifications debug: Query1 failed");
        }
        
        // Second query: tickets assigned to user
        $ch = curl_init();
        curl_setopt_array($ch, [
            CURLOPT_URL => $supabaseUrl . '/rest/v1/tickets?' . $query2,
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_HTTPHEADER => [
                'apikey: ' . $supabaseKey,
                'Authorization: Bearer ' . $supabaseKey,
                'Accept: application/json',
            ],
        ]);
        
        $response = curl_exec($ch);
        $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        curl_close($ch);
        
        error_log("Notifications debug: Query2 HTTP code = " . $httpCode);
        error_log("Notifications debug: Query2 response = " . $response);
        
        if ($httpCode === 200 && $response) {
            $tickets2 = json_decode($response, true) ?: [];
            error_log("Notifications debug: Query2 decoded tickets = " . print_r($tickets2, true));
            $allTickets = array_merge($allTickets, $tickets2);
        } else {
            error_log("Notifications debug: Query2 failed");
        }
        
        // Remove duplicates and sort by created_at
        $uniqueTickets = [];
        $seenIds = [];
        foreach ($allTickets as $ticket) {
            if (!in_array($ticket['id'], $seenIds)) {
                $seenIds[] = $ticket['id'];
                $uniqueTickets[] = $ticket;
            }
        }
        
        // Sort by created_at descending
        usort($uniqueTickets, function($a, $b) {
            return strtotime($b['created_at']) - strtotime($a['created_at']);
        });
        
        $recentTickets = array_slice($uniqueTickets, 0, 5);
    }
    
    error_log("Notifications debug: Final recent tickets count = " . count($recentTickets));
    error_log("Notifications debug: Final recent tickets = " . print_r($recentTickets, true));
} else {
    error_log("Notifications debug: Skipped - missing Supabase config or email");
}

// Generate initials as fallback
$initials = '';
if (!empty($_SESSION['user_name'])) {
    $parts = preg_split('/\s+/', trim($_SESSION['user_name']));
    if (count($parts) >= 2) {
        $initials = strtoupper(mb_substr($parts[0], 0, 1) . mb_substr(end($parts), 0, 1));
    } else {
        $initials = strtoupper(mb_substr($parts[0], 0, 2));
    }
} elseif (!empty($email)) {
    $initials = strtoupper(mb_substr($email, 0, 2));
} else {
    $initials = 'U';
}
?>

<!-- Create Button Dropdown -->
<div class="dropdown me-2">
    <button
        class="btn btn-sm btn-outline-success"
        type="button"
        id="createDropdown"
        data-bs-toggle="dropdown"
        aria-expanded="false"
        title="Create New"
    >
        <i class="bi bi-plus-lg"></i>Create
    </button>
    <ul class="dropdown-menu dropdown-menu-end">
        <li><a class="dropdown-item" href="#" onclick="openCreateTicketModal(); return false;">
            <i class="bi bi-ticket-detailed me-2"></i>New Ticket
        </a></li>
        <li><a class="dropdown-item" href="#" onclick="openCreateJobCardModal(); return false;">
            <i class="bi bi-card-list me-2"></i>New Job Card
        </a></li>
    </ul>
</div>

<!-- Notifications Dropdown -->
<div class="dropdown me-2">
    <button
        class="btn btn-sm btn-outline-secondary rounded-circle position-relative d-none d-sm-inline-flex"
        type="button"
        id="notificationDropdown"
        data-bs-toggle="dropdown"
        aria-expanded="false"
    >
        <i class="bi bi-bell"></i>
        <?php if (!empty($recentTickets)) : ?>
            <span class="position-absolute top-0 start-100 translate-middle badge rounded-pill bg-danger">
                <?php echo count($recentTickets); ?>
                <span class="visually-hidden">unread notifications</span>
            </span>
        <?php endif; ?>
    </button>
    <ul class="dropdown-menu dropdown-menu-end" style="min-width: 320px; max-height: 400px; overflow-y: auto;">
        <li><h6 class="dropdown-header">Open Tickets</h6></li>
        <?php if (empty($recentTickets)) : ?>
            <li><span class="dropdown-item-text text-muted small">No open tickets</span></li>
        <?php else : ?>
            <?php foreach ($recentTickets as $ticket) : ?>
                <li>
                    <a class="dropdown-item ticket-notification-item" href="#" 
                       data-ticket-id="<?php echo htmlspecialchars($ticket['id'], ENT_QUOTES, 'UTF-8'); ?>"
                       data-ticket-title="<?php echo htmlspecialchars($ticket['title'], ENT_QUOTES, 'UTF-8'); ?>"
                       data-ticket-status="<?php echo htmlspecialchars($ticket['status'], ENT_QUOTES, 'UTF-8'); ?>"
                       data-ticket-priority="<?php echo htmlspecialchars($ticket['priority'], ENT_QUOTES, 'UTF-8'); ?>"
                       data-ticket-created-at="<?php echo htmlspecialchars($ticket['created_at'], ENT_QUOTES, 'UTF-8'); ?>"
                       data-ticket-requested-by="<?php echo htmlspecialchars($ticket['requested_by'], ENT_QUOTES, 'UTF-8'); ?>"
                       style="white-space: normal; padding: 12px 16px; cursor: pointer;">
                        <div class="d-flex justify-content-between align-items-start mb-1">
                            <strong class="text-truncate" style="max-width: 200px;">
                                <?php echo htmlspecialchars(substr($ticket['title'], 0, 40), ENT_QUOTES, 'UTF-8'); ?>
                                <?php if (strlen($ticket['title']) > 40) echo '...'; ?>
                            </strong>
                            <?php
                            $statusClass = '';
                            $statusIcon = '';
                            switch (strtolower($ticket['status'])) {
                                case 'open':
                                    $statusClass = 'text-primary';
                                    $statusIcon = 'bi-circle';
                                    break;
                                case 'in progress':
                                    $statusClass = 'text-warning';
                                    $statusIcon = 'bi-arrow-repeat';
                                    break;
                                case 'resolved':
                                    $statusClass = 'text-success';
                                    $statusIcon = 'bi-check-circle';
                                    break;
                                case 'closed':
                                    $statusClass = 'text-secondary';
                                    $statusIcon = 'bi-x-circle';
                                    break;
                                default:
                                    $statusClass = 'text-muted';
                                    $statusIcon = 'bi-circle';
                            }
                            ?>
                            <small class="<?php echo $statusClass; ?>">
                                <i class="bi <?php echo $statusIcon; ?> small"></i>
                            </small>
                        </div>
                        <div class="d-flex justify-content-between align-items-center">
                            <small class="text-muted">
                                <?php 
                                $createdAt = new DateTime($ticket['created_at']);
                                echo $createdAt->format('M j, H:i');
                                ?>
                            </small>
                            <?php
                            $priorityClass = '';
                            $priorityText = '';
                            switch (strtolower($ticket['priority'])) {
                                case 'high':
                                    $priorityClass = 'bg-danger';
                                    $priorityText = 'H';
                                    break;
                                case 'medium':
                                    $priorityClass = 'bg-warning';
                                    $priorityText = 'M';
                                    break;
                                case 'low':
                                    $priorityClass = 'bg-info';
                                    $priorityText = 'L';
                                    break;
                                default:
                                    $priorityClass = 'bg-secondary';
                                    $priorityText = 'N';
                            }
                            ?>
                            <span class="badge <?php echo $priorityClass; ?> text-white" style="font-size: 0.65em;">
                                <?php echo $priorityText; ?>
                            </span>
                        </div>
                    </a>
                </li>
            <?php endforeach; ?>
        <?php endif; ?>
        <li><hr class="dropdown-divider" /></li>
        <li><a class="dropdown-item small text-center" href="  tickets">View All Tickets</a></li>
        <li><a class="dropdown-item small text-center" href="  job_cards">View Job Cards</a></li>
    </ul>
</div>

<script>
// Function to open create ticket modal
function openCreateTicketModal() {
    // Check if we're on tickets page
    if (window.location.pathname.includes('/tickets')) {
        // We're on tickets page, open modal directly
        console.log('Create debug: On tickets page, opening create modal');
        
        // Wait a bit for main scripts to load
        setTimeout(() => {
            const createBtn = document.getElementById('createTicketBtn');
            if (createBtn) {
                createBtn.click();
            } else {
                console.error('Create debug: Create ticket button not found');
            }
        }, 500);
    } else {
        // Redirect to tickets page with create flag
        console.log('Create debug: Redirecting to tickets page');
        const form = document.createElement('form');
        form.method = 'POST';
        form.action = '  tickets';
        
        const flagInput = document.createElement('input');
        flagInput.type = 'hidden';
        flagInput.name = 'open_create_modal';
        flagInput.value = '1';
        form.appendChild(flagInput);
        
        document.body.appendChild(form);
        form.submit();
    }
}

// Function to open create job card modal
function openCreateJobCardModal() {
    // Check if we're on job cards page
    if (window.location.pathname.includes('/job_cards')) {
        // We're on job cards page, open modal directly
        console.log('Create debug: On job cards page, opening create modal');
        
        // Wait a bit for main scripts to load
        setTimeout(() => {
            const createBtn = document.getElementById('createJobCardBtn');
            if (createBtn) {
                createBtn.click();
            } else {
                console.error('Create debug: Create job card button not found');
            }
        }, 500);
    } else {
        // Redirect to job cards page with create flag
        console.log('Create debug: Redirecting to job cards page');
        const form = document.createElement('form');
        form.method = 'POST';
        form.action = '  job_cards';
        
        const flagInput = document.createElement('input');
        flagInput.type = 'hidden';
        flagInput.name = 'open_create_modal';
        flagInput.value = '1';
        form.appendChild(flagInput);
        
        document.body.appendChild(form);
        form.submit();
    }
}

document.addEventListener('DOMContentLoaded', function() {
    // Handle ticket notification item clicks
    const ticketNotificationItems = document.querySelectorAll('.ticket-notification-item');
    
    console.log('Notifications debug: Found ticket items:', ticketNotificationItems.length);
    
    ticketNotificationItems.forEach(function(item) {
        item.addEventListener('click', function(e) {
            e.preventDefault();
            e.stopPropagation();
            
            console.log('Notifications debug: Ticket item clicked');
            
            // Get ticket data from data attributes
            const ticketData = {
                id: this.dataset.ticketId,
                title: this.dataset.ticketTitle,
                status: this.dataset.ticketStatus,
                priority: this.dataset.ticketPriority,
                created_at: this.dataset.ticketCreatedAt,
                requested_by: this.dataset.ticketRequestedBy
            };
            
            console.log('Notifications debug: Ticket data:', ticketData);
            
            // Check if we're on the tickets page (has notes modal)
            const notesModal = document.getElementById('ticketNotesModal');
            console.log('Notifications debug: Notes modal found:', !!notesModal);
            
            if (notesModal) {
                // We're on tickets page, open notes modal directly
                console.log('Notifications debug: Opening notes modal directly');
                
                // Wait a bit for the main scripts to load
                setTimeout(() => {
                    if (typeof openNotesView === 'function') {
                        console.log('Notifications debug: openNotesView function exists, calling it');
                        openNotesView(ticketData);
                    } else {
                        console.error('Notifications debug: openNotesView function still not found after delay');
                        // Try to find the function in window scope
                        if (typeof window.openNotesView === 'function') {
                            console.log('Notifications debug: Found openNotesView in window scope');
                            window.openNotesView(ticketData);
                        } else {
                            console.error('Notifications debug: openNotesView function not found anywhere');
                        }
                    }
                }, 1000); // Wait 1 second for main scripts to load
            } else {
                // We're not on tickets page, redirect to tickets page with ticket data
                console.log('Notifications debug: Redirecting to tickets page');
                const form = document.createElement('form');
                form.method = 'POST';
                form.action = '  tickets';
                
                // Add ticket data as hidden fields
                Object.keys(ticketData).forEach(key => {
                    const input = document.createElement('input');
                    input.type = 'hidden';
                    input.name = 'notes_ticket_' + key;
                    input.value = ticketData[key];
                    form.appendChild(input);
                });
                
                // Add a flag to indicate we want to open notes modal
                const flagInput = document.createElement('input');
                flagInput.type = 'hidden';
                flagInput.name = 'open_notes_modal';
                flagInput.value = '1';
                form.appendChild(flagInput);
                
                document.body.appendChild(form);
                form.submit();
            }
            
            // Close the dropdown
            const dropdownButton = this.closest('.dropdown').querySelector('[data-bs-toggle="dropdown"]');
            if (dropdownButton) {
                const dropdown = bootstrap.Dropdown.getInstance(dropdownButton);
                if (dropdown) {
                    dropdown.hide();
                }
            }
        });
    });
});
</script>
